package com.example.extreamprogrammingtestone;

public class PersonalinfoMessage {
    static String user="";
    static String psw="";
    public  void setUser(String user){
        this.user=user;
    }
    public static String getUser(){
        return user;
    }
    public void setPsw(String psw){
        this.psw=psw;
    }
    public static String getPsw(){
        return psw;
    }
}
