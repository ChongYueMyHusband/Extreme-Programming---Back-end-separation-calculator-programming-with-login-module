package com.example.extreamprogrammingtestone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EmotionDiaryActivityActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emotion_diary_activity);
    }
}